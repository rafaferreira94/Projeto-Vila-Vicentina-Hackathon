app.controller("contriController", ["$scope", "$http", function ($scope, $http) {
$scope.editDoa = false;
$scope.editPre = false;
$scope.editBaz = false;
}]);
