app.controller("transpController", ["$scope",'textAngularManager', "$http", function ($scope, textAngularManager, $http) {
    $scope.htmlVariable='Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut.';
    $scope.edit=false;
  }]);
