app.controller("histController", ["$scope",'textAngularManager', "$http", function ($scope, textAngularManager, $http) {
    $scope.htmlVariable='<h2>Como Surgiu?</h2> <p>A Sociedade São Vicente de Paulo foi fundada sob a inspiração de São Vicente de Paulo, por Antônio Frederico Ozanam e seus companheiros, no ano de 1.833, em Paris. Esta Entidade, com o correr do tempo, se constituiu em uma fortaleza na defesa dos direitos humanos dos excluídos, zelando pelo restabelecimento do respeito contra as discriminações e violências, buscando evangelizar o homem, protestando contra as injustiças e atuando na salvaguarda da cidadania.</p>';
    $scope.edit=false;
  }]);
