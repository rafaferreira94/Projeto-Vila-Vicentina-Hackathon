app.controller("headerController", ["$scope", "$http", function ($scope, $http) {
$scope.edit = false;
$scope.titulo = "Vila Vicentina";
$scope.bio = "Lar para idosos";

$scope.onClickSave= function(){
  var data =
      {
        "idHome": "",
        "titulo": $scope.titulo,
        "bio": $scope.bio
      };
      console.log(data);

  var requisicao = {
      method: 'POST',
      url: 'http://localhost/VilaVicentinaProvider/api/home',
      headers: {"Content-Type": "application/json", "Access-Control-Allow-Origin": "*"},
      data: data
  };

  $http(requisicao).then(function successCallback(response) {
              var data = response.data;
              console.log(data);
              if (data == "true") {
                  alert("Atualizado com sucesso!");
              } else {
                  alert("Erro ao alterar!");
              }

          }, function errorCallback(response) {
              alert("Ocorreu um erro ao realizar a requisição");
              console.log(response);
          });
}
}]);
